COPY "adb" folder to the root unit of your computer, ie:

	C:\ ->This is the unit's root, therefore we will obtain:

	C:\adb\

Copiar la carpeta "adb" a la ra�z del pc, por ejemplo:

	C:\ ->Esta es la ra�z de la unidad, por lo tanto despu�s de copiar obtendremos:

	C:\adb\